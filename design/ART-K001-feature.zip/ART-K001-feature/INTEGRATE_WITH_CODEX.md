# ART / K-001 — интеграция в актуальный проект Codex

**Важно:** текущие изменения Codex существуют только в локальном проекте разработчика; эта папка — самостоятельная feature-заготовка и интерактивное демо, а НЕ замена всего проекта.

## Задача
Встроить пасхалку К-001 в текущую ветку ART v1.0, НЕ откатывая правки уроков, Gemini, навигации или палитры.

## Файлы
- `src/features/k001/exhibit.mjs` — чистая логика: 7 уникальных сохранённых произведений, классификация по периоду, варианты текстов, последние 3 цвета.
- `src/features/k001/k001.css` — изолированный стиль музейной карточки, адаптивная модалка.
- `src/features/k001/k001.profile.snippet.html` — секретная строка в «Автопортрете».
- `src/features/k001/k001.modal.snippet.html` — полный экспонат.
- `tests/k001.test.mjs` — проверки логики; запустить `node --test tests/k001.test.mjs`.
- `demo/` — отдельная демонстрация (локальный HTTP-сервер; здесь достаточно сохранить 7-ю картину).

## 1. Копирование
Скопировать feature в `src/features/k001/`. Внести изменения в сборку: опубликовать `exhibit.mjs` и `k001.css` в тех же относительных путях (шаблонные `.html` файлы копировать не требуется, они встраиваются в настоящий шаблон приложения).

## 2. Состояние и открытие
Для Vue 3 Composition API (адаптировать к текущей архитектуре стора):

```js
import {K001_ID, shouldUnlockK001, getK001Exhibit} from './features/k001/exhibit.mjs';

const k001Open = ref(false);
const k001Revision = ref(0);
// db.favorites: array of artwork ID, db.discoveredExhibits: array of secret IDs
const k001Discovered = computed(() => db.discoveredExhibits?.includes(K001_ID) === true);

watch(() => db.favorites, (favorites) => {
  if (shouldUnlockK001(favorites || [], artworks) && !k001Discovered.value) {
    if (!Array.isArray(db.discoveredExhibits)) db.discoveredExhibits = [];
    db.discoveredExhibits.push(K001_ID);
    // No toast, confetti or announcement. The surprise is intentionally quiet.
  }
}, {deep:true, immediate:true});

const k001Exhibit = computed(() => getK001Exhibit({
  favorites: db.favorites || [],
  artworks,
  savedColors: db.savedColors || [],
  revision: k001Revision.value
}));
```

Add `k001Open, k001Revision, k001Discovered, k001Exhibit` to the bindings exposed to the template. When navigating elsewhere, close the modal if desired. Add Escape handling + focus management in the host app if the app has a shared modal system.

## 3. Данные и JSON-архив
In the local profile/store default add `discoveredExhibits: []` (or equivalent set). Persist through the same existing IndexedDB mechanism as favorites. Include `discoveredExhibits` in JSON export and import; validate against an explicit allowed list (`['k001']`). Discovery remains after dropping favorites below 7. No migration of old profile schema required as requested for v1.0.

## 4. UI
Insert the contents of `k001.profile.snippet.html` in the **profile** view after the gallery and before colors or archive. Insert `k001.modal.snippet.html` alongside other dialog elements, outside any `v-if=page==='profile'` block. Import `k001.css` through a stylesheet link or actual app CSS bundler.

The secret line is invisible until seven **distinct known** artwork IDs are in favorites. The modal content changes based on the most frequent period among favorites. Tie-breaker: most recently saved favorite. Button «Запросить повторную экспертизу» cycles through a fixed list of conclusions; no LLM/API calls.

The portrait SVG uses the last 3 colors saved by the user. All other UI remains neutral monochrome. Styling is scoped to `k001-` classes and avoids the SVG masks/filters known to render incorrectly in iOS Safari.

## 5. Критерии приёмки
- With 6 or fewer valid artwork IDs: secret is absent.
- With the 7th distinct valid artwork ID: secret appears silently in Автопортрет.
- Removing artworks does not make a discovered secret disappear.
- Classification follows favorite art periods, updating if preferences change.
- Reopen / reload: discovery persists via IndexedDB and JSON backup.
- No API, background requests, additional network dependencies or personal data transmission.
- Doesn't change ART icon, topbar or bottom nav.
- Dialog closes by Close and backdrop; Escape + focus management in app shell.
- Test on 375/390/430 px and desktop; Safari iOS must be checked on device.
- Bump SW/cache revision and verify the new JS/CSS files reach the Netlify `dist` directory.
- **Important:** The earlier seed catalog contains only 6 artworks. Ensure the new published catalog has at least 7 distinct works before testing the real unlock (or add 7 verified works). Don't secretly lower the production threshold.

## 6. Тон
All UI copy deliberately resembles sober museum bureaucratic language. Do NOT add obvious gamification, badges, progress counters or a notice announcing an achievement. Do NOT mention this hidden feature outside the secret card.
