/**
 * ART / K-001. Offline, deterministic easter egg.
 * Pure functions: no API calls, timers, browser state or runtime side effects.
 */
export const K001_ID = 'k001';
export const K001_REQUIRED_ARTWORKS = 7;
export const K001_NEUTRAL_COLORS = Object.freeze(['#B4B5B2', '#D0D0CD', '#747774']);

const profiles = Object.freeze({
  prehistoric: {
    heading: 'Мужичок раннего периода',
    period: 'Время создания: устанавливается по косвенным признакам',
    observation: 'Экземпляр удивительно хорошо сохранился. Признаки цивилизации присутствуют выборочно.',
  },
  ancient: {
    heading: 'Мужичок государственной важности',
    period: 'Неустановленная древняя династия',
    observation: 'Поза монументальна. Требования к окружающим соответствующие.',
  },
  classical: {
    heading: 'Мужичок идеальных пропорций',
    period: 'Классическая школа',
    observation: 'Пропорции оспариваются, самооценка — нет.',
  },
  medieval: {
    heading: 'Мужичок, обнаруженный в манускрипте',
    period: 'Неизвестный монастырский скрипторий',
    observation: 'На полях оставлены комментарии, не прошедшие церковную цензуру.',
  },
  renaissance: {
    heading: 'Мужичок эпохи гуманизма',
    period: 'Возрождение. Особо редкий экземпляр',
    observation: 'Проявляет живой интерес к человеку. Особенно если человек — он сам.',
  },
  baroque: {
    heading: 'Драматический мужичок с претензией на величие',
    period: 'Барокко. Высокая степень театральности',
    observation: 'Предпочитает эффектный свет и выходы с выражением лица.',
  },
  romanticism: {
    heading: 'Мужичок на фоне сложной душевной погоды',
    period: 'Романтизм. Пейзаж внутренний',
    observation: 'Смотрит вдаль, поскольку поблизости всё уже прокомментировал.',
  },
  impressionism: {
    heading: 'Мужичок при естественном освещении',
    period: 'Импрессионизм. Состояние изменчивое',
    observation: 'При попытке зафиксировать мгновение заявил, что оно уже прошло.',
  },
  postimpressionism: {
    heading: 'Мужичок повышенной эмоциональной насыщенности',
    period: 'Постимпрессионизм. Цветовая перегрузка',
    observation: 'Объективность цвета отклонена экспертным советом.',
  },
  surrealism: {
    heading: 'Мужичок. Авторство реальности оспаривается',
    period: 'Сюрреализм. Происхождение неясно',
    observation: 'По словам очевидцев, объект присутствовал одновременно в двух разговорах.',
  },
  modern: {
    heading: 'Мужичок, выполненный с нарушением пропорций',
    period: 'Авангард. Форма экспериментальная',
    observation: 'Попытки объяснить объект привели к появлению новых вопросов.',
  },
  contemporary: {
    heading: 'Мужичок как самостоятельное высказывание',
    period: 'Современное искусство. Смешанная техника',
    observation: 'Сам факт присутствия уже объявлен перформансом.',
  },
  mixed: {
    heading: 'Мужичок. Сложная атрибуция',
    period: 'Смешанный период. XXI век',
    observation: 'Сочетает несовместимые художественные традиции и считает это личным достижением.',
  },
});

const conclusions = Object.freeze([
  'Объект демонстрирует признаки художественного вкуса. При попытке классификации назвал комиссию душнилами.',
  'В ходе реставрации обнаружен характер. Реставраторы просят больше его не трогать.',
  'Эксперты разошлись во мнениях. Экспонат потребовал книгу жалоб и лучший свет.',
  'На просьбу объяснить свой выбор цветов объект ответил: «Красиво же». Комиссия затруднилась возразить.',
  'Экспонат рекомендовано оставить в естественной среде обитания. Контактировать бережно.',
]);

const asId = entry => typeof entry === 'string' ? entry : entry?.artworkId || entry?.id;
const legitHex = v => typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v);
const normal = v => String(v || '').toLowerCase();

function periodKey(art) {
  const tags = [art.periodId, art.style, art.styleId, art.movement, ...(art.periodIds || []), ...(art.styleIds || [])].map(normal);
  const matches = key => tags.some(tag => tag.includes(key));
  if (matches('surreal')) return 'surrealism';
  if (matches('postimpression') || matches('post-impression')) return 'postimpressionism';
  if (matches('impression')) return 'impressionism';
  if (matches('renaissance')) return 'renaissance';
  if (matches('baroque') || matches('rococo')) return 'baroque';
  if (matches('romanti') || matches('realism')) return 'romanticism';
  if (matches('prehistor') || matches('paleolith')) return 'prehistoric';
  if (matches('ancient') || matches('egypt') || matches('mesopot')) return 'ancient';
  if (matches('classical') || matches('antiquity')) return 'classical';
  if (matches('medieval') || matches('gothic') || matches('byzant')) return 'medieval';
  if (matches('modern') || matches('avant') || matches('cubism')) return 'modern';
  if (matches('contemporary')) return 'contemporary';
  return 'mixed';
}

export function favoriteArtworkRecords(favorites = [], catalog = []) {
  const map = new Map(catalog.map(art => [art.id, art]));
  const visited = new Set();
  return favorites.map(asId).filter(id => {
    if (typeof id !== 'string' || visited.has(id) || !map.has(id)) return false;
    visited.add(id);
    return true;
  }).map(id => map.get(id));
}

export function shouldUnlockK001(favorites, catalog) {
  return favoriteArtworkRecords(favorites, catalog).length >= K001_REQUIRED_ARTWORKS;
}

export function getK001Palette(colors = []) {
  const valid = colors.map((color, index) => ({
    hex: typeof color === 'string' ? color : color.hex,
    stamp: typeof color === 'object' && color?.savedAt ? Date.parse(color.savedAt) : NaN,
    index,
  })).filter(color => legitHex(color.hex));
  // When savedAt exists, prefer chronological order; otherwise keep insertion order.
  if (valid.every(c => Number.isFinite(c.stamp))) {
    valid.sort((a, b) => a.stamp - b.stamp || a.index - b.index);
  }
  const last = valid.slice(-3).map(c => c.hex);
  return last.length ? last : K001_NEUTRAL_COLORS.slice();
}

export function getK001Era(favorites, catalog) {
  const records = favoriteArtworkRecords(favorites, catalog);
  if (!records.length) return 'mixed';
  const counter = new Map();
  records.forEach((art, i) => {
    const key = periodKey(art);
    const prev = counter.get(key) || { count:0, latest:-1 };
    counter.set(key, { count:prev.count + 1, latest:i });
  });
  return [...counter].sort((a, b) => b[1].count - a[1].count || b[1].latest - a[1].latest)[0][0];
}

export function getK001Exhibit({ favorites = [], artworks = [], savedColors = [], revision = 0 } = {}) {
  const era = getK001Era(favorites, artworks);
  const profile = profiles[era] || profiles.mixed;
  const safeRevision = Number.isFinite(revision) ? Math.max(0, Math.floor(revision)) : 0;
  return {
    id: 'К-001',
    name: 'МУЖИЧОК.',
    era,
    heading: profile.heading,
    period: profile.period,
    observation: profile.observation,
    conclusion: conclusions[safeRevision % conclusions.length],
    material: 'Мясо, сарказм, художественный вкус',
    condition: 'Удовлетворительное. Местами прекрасное.',
    attribution: 'Предположительно Катя',
    value: 'Не подлежит оценке',
    protection: 'НАЦИОНАЛЬНОЕ ДОСТОЯНИЕ. ВЫВОЗУ НЕ ПОДЛЕЖИТ.',
    palette: getK001Palette(savedColors),
    favoriteCount: favoriteArtworkRecords(favorites, artworks).length,
  };
}
