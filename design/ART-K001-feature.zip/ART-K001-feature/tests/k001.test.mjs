import test from 'node:test';
import assert from 'node:assert/strict';
import { shouldUnlockK001, getK001Exhibit, getK001Palette, getK001Era } from '../src/features/k001/exhibit.mjs';
const catalog = [
  ...Array.from({length:5},(_,i)=>({id:'r'+i,periodId:'renaissance'})),
  ...Array.from({length:3},(_,i)=>({id:'i'+i,periodId:'impressionism'})),
  {id:'s',periodId:'modern',styleIds:['surrealism']},
];
const ids = catalog.map(a=>a.id);
test('unlock at 7 valid unique catalog art IDs, not arbitrary strings',()=>{
  assert.equal(shouldUnlockK001(ids.slice(0,6),catalog),false);
  assert.equal(shouldUnlockK001([...ids.slice(0,6),'invalid','r0'],catalog),false);
  assert.equal(shouldUnlockK001(ids.slice(0,7),catalog),true);
});
test('mixed time picks dominant era; tie chooses latest saved favorite',()=>{
  assert.equal(getK001Era(['r0','r1','r2','i0','i1'],catalog),'renaissance');
  assert.equal(getK001Era(['r0','r1','i0','i1'],catalog),'impressionism');
  assert.equal(getK001Era(['s'],catalog),'surrealism');
});
test('palette selects last three valid saved colors',()=>{
  assert.deepEqual(getK001Palette(['#111111','#222222','#333333','#444444']),['#222222','#333333','#444444']);
  assert.deepEqual(getK001Palette([{hex:'#111111'},{hex:'red'},{hex:'#AABBCC'}]),['#111111','#AABBCC']);
  assert.equal(getK001Palette([]).length,3);
});
test('exhibit is deterministic and changes official conclusion only on revision',()=>{
  const input={favorites:ids.slice(0,7),artworks:catalog,savedColors:['#111111','#222222','#333333']};
  const a=getK001Exhibit(input);
  assert.deepEqual(getK001Exhibit(input),a);
  assert.equal(a.id,'К-001');
  assert.match(a.heading,/Мужичок/);
  assert.notEqual(getK001Exhibit({...input,revision:1}).conclusion,a.conclusion);
});
